#!/usr/bin/bash
#SBATCH --nodes 1
#SBATCH -t 1-00:00:00
#SBATCH -p debug 
#SBATCH --mem=60G
#SBATCH --partition=cpu
#SBATCH --cpus-per-task 1
#SBATCH --exclude=mind-1-23


cd /user_data/isaacl/cosyne-submission-runs/analysis
source ~/miniconda3/etc/profile.d/conda.sh
conda activate tangvit
python extract_corrs.py m2s1