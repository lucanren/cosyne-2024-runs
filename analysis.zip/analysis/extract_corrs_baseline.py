import os
import sys
sys.path.append('/user_data/isaacl/cosyne-submission-runs/modeling/')
sys.path.append('/user_data/isaacl/cosyne-submission-runs/')
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
from torch import nn
from torch import Tensor
from PIL import Image
from torchvision.transforms import Compose, Resize, ToTensor
from einops import rearrange, reduce, repeat
from einops.layers.torch import Rearrange, Reduce
from torchsummary import summary
from torch.utils.data import Dataset,DataLoader
from utils import *

from modeling.model_0a import *
from modeling.model_0b import *
from modeling.model_0c import *

site = sys.argv[1]

vimg = np.load(f'../../all_sites_data_prepared/pics_data/val_img_{site}.npy')
vresp = np.load(f'../../all_sites_data_prepared/New_response_data/valRsp_{site}.npy')
vimg = np.reshape(vimg,(1000,1,50,50))

dic = dict()

for model_num in ["0a","0b","0c"]:
    dic[model_num] = []
    rootdir = f'../results/{site}/model_{model_num}'

    for subdir, dirs, files in os.walk(rootdir):
        if 'model' not in files[0] or subdir[-3:] == 'avg':
            continue

        neuron_number = int(subdir.split("_")[-1])

        files.sort(key = lambda x: int(x.split(".")[0].split("_")[-1]),reverse=True)

        if model_num == "0a":
            net = model_0a_one_neuron()
        if model_num == "0b":
            net = model_0b_one_neuron()
        if model_num == "0c":
            net = model_0c_one_neuron()
        net.load_state_dict(torch.load(subdir + "/" + files[0], map_location=torch.device('cpu')))

        net_resp = torch.from_numpy(np.float32(vimg))
        with torch.no_grad():
            net.eval()
            net_resp = net(net_resp).detach().numpy()
        net_resp = np.transpose(net_resp)[0]

        real_resp = vresp[:,neuron_number]
        real_resp = np.transpose(real_resp)

        comb_resp_ord = []
        for r,n in zip(real_resp,net_resp):
            comb_resp_ord.append((r,n))
        comb_resp_ord.sort(key = lambda x:x[0],reverse=True)
        dic[model_num].append((neuron_number,pc_one_neuron(net,neuron_number,vimg,vresp), comb_resp_ord))

    dic[model_num].sort(key= lambda x: x[0])
    np.save(f'backup_{model_num}_{site}_pc_cro_baseline',dic)

np.save(f'{site}_pc_cro_baseline',dic)