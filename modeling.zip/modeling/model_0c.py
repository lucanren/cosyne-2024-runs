import torch
import torch.nn as nn
import numpy as np

class net_one_neuron_m0c(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers_1 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=30, kernel_size=(5, 5), stride=(1, 1)),
            nn.MaxPool2d(kernel_size=2),
            nn.BatchNorm2d(30),
            nn.Sigmoid(),
            nn.Dropout2d(0.3),
            nn.Conv2d(in_channels=30, out_channels=30, kernel_size=(5, 5), stride=(1, 1)),
            nn.MaxPool2d(kernel_size=2),
            nn.BatchNorm2d(30),
            nn.Sigmoid(),
            nn.Dropout2d(0.3)
         ) #[N,30,9,9] 
        
        self.Linear = nn.Linear(30, 1)

    def forward(self, x):
        x = self.layers_1(x)
        x = x.reshape(-1,30,81)
        x = x[:,:,40]
        x = self.Linear(x)
        return x


class seperate_core_model_m0c(nn.Module):
    def __init__(self,num_neurons):
        super().__init__()
        self.models = nn.ModuleList([net_one_neuron_m0c() for i in range(num_neurons)])
        self.num_neurons = num_neurons

    def forward(self, x):
        outputs = [self.models[i].forward(x) for i in range(self.num_neurons)]
        outputs = torch.stack(outputs, dim=1)
        return outputs.reshape((outputs.shape[0], outputs.shape[1]))

def model_0c(num_neurons):
    return seperate_core_model_m0c(num_neurons=num_neurons)

def model_0c_one_neuron():
    return net_one_neuron_m0c()